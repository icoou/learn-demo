define(function(require, exports, module) {

  // 通过 require 引入依赖
  var $ = require('jquery');
  var Spinning = require('hoverColor');
  var Spinnin = require('repeat.js');

});